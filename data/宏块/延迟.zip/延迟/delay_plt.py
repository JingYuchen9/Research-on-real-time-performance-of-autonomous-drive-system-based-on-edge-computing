import matplotlib.pyplot as plt
import os
################# 周末 晚 ####################
# file1 = './use_others_model/kookmin5g_night/'
# file2 = './not_use_model/kookmin5g_night/' # 4 5
# file3 = './use_my_model/kookmin5g_night/'
################# 周末 中 ####################
# file1 = './use_others_model/kookmin5g_afternoon/'
# file2 = './not_use_model/kookmin5g_afternoon/' # 4 5
# file3 = './use_my_model/kookmin5g_afternoon/'
################# 周末 早 ####################
file1 = './use_others_model/kookmin5g_morning/'
file2 = './not_use_model/kookmin5g_morning/' # 4 5
file3 = './use_my_model/kookmin5g_morning/'
################# 周三 晚 ####################
# file1 = './use_others_model/kookmin5g_night/'
# file2 = './not_use_model/kookmin5g_night/' # 4 5
# file3 = './use_my_model/kookmin5g_night/'
################# 周三 中 ####################
# file1 = './use_others_model/kookmin5g_afternoon/'
# file2 = './not_use_model/kookmin5g_afternoon/' # 4 5
# file3 = './use_my_model/kookmin5g_afternoon/'

################# 周三 早 ####################
# file1 = './use_others_model/kookmin5g_morning/'
# file2 = './not_use_model/kookmin5g_morning/' # 4 5
# file3 = './use_my_model/kookmin5g_morning/'

############ 冤枉 ####################
# Step 1: 读取文件中的数据
# file1 = './use_others_model/125/'
# file2 = './not_use_model/125/' # 4 5
# file3 = './use_my_model/120/' # 5 7 9 10
# file4 = './lab/RTT.txt'
# file5 = './no_model_lab/RTT.txt'

# 读取数据
# with open(file4, 'r') as f4, open(file5, 'r') as f5:
#     # data1 = f1.readlines()
#     # data2 = f2.readlines()
#     # data3 = f3.readlines()
#     data4 = f4.readlines()
#     data5 = f5.readlines()

# 初始化数据列表
all_data_my = []
all_data_no = []
all_data_other = []

for i in range(6, 11):
    print(i)
    file_path = os.path.join(file1, str(i), 'RTT.txt')
    try:
        with open(file_path, 'r') as file:
            data = file.readlines()
            # 将数据转换为浮点数并乘以1000，过滤掉空行
            data = [float(value.strip()) * 1000 for value in data if value.strip()]
            # 将所有数据加入到总列表中
            all_data_other.extend(data)
    except FileNotFoundError:
        print(f"文件 {file_path} 未找到，跳过。")

for i in range(6, 11):
    print(i)
    file_path = os.path.join(file2, str(i), 'RTT.txt')
    try:
        with open(file_path, 'r') as file:
            data = file.readlines()
            # 将数据转换为浮点数并乘以1000，过滤掉空行
            data = [float(value.strip()) * 1000 for value in data if value.strip()]
            # 将所有数据加入到总列表中
            all_data_no.extend(data)
    except FileNotFoundError:
        print(f"文件 {file_path} 未找到，跳过。")

# 遍历 1 到 10 的文件夹
for i in range(6, 11):
    # print(i)
    file_path = os.path.join(file3, str(i), 'RTT.txt')
    try:
        with open(file_path, 'r') as file:
            data = file.readlines()
            # 将数据转换为浮点数并乘以1000，过滤掉空行
            # data = [float(value.strip()) * 1000 for value in data if value.strip()]
            data = [(float(value.strip()) * 1000) for value in data if value.strip()]
            # 将所有数据加入到总列表中
            all_data_my.extend(data)
    except FileNotFoundError:
        print(f"文件 {file_path} 未找到，跳过。")

# 数据预处理，将字符串转换为浮点数
# data1 = [float(value.replace('\x00', '').strip()) * 1000 for value in data1]
# data2 = [float(value.strip())*1000 for value in data2 if value.strip()]
# data3 = [float(value.strip())*1000 for value in data3 if value.strip()]
# data4 = [float(value.strip())*1000 for value in data4 if value.strip()]
# data4 = [float(value.strip())*1000 for value in data4]
# data5 = [float(value.strip())*1000 for value in data5 if value.strip()]

# 排除前100个数据
# data1 = data1[50:]
# data2 = data2[50:]
# data3 = data3[50:]

# 抽样显示数据（例如，每10个点取一个点）
# sampling_interval = 10
# data1_sampled = data1[::sampling_interval]
# data2_sampled = data2[::sampling_interval]
# data3_sampled = data3[::sampling_interval]
plt.yticks(range(0, 901, 50))  # 从40到900，步长为50
# 绘制散点图
# all_data_other = all_data_other[::1]
# all_data_no = all_data_no[::1]
# all_data_my = all_data_my[::1]

# plt.scatter(range(len(data4)), data4, color='b', marker='x', label='not_use_model')

# plt.scatter(range(len(all_data_other)), all_data_other, color='lime', marker='x', label='SegNetwork',alpha = 0.6)
# print(sum(all_data_other) / len(all_data_other))

plt.scatter(range(len(all_data_no)), all_data_no, color='b', marker='*', label='No Model',alpha = 0.5)
print(sum(all_data_no) / len(all_data_no))

plt.scatter(range(len(all_data_my)), all_data_my, color='r', marker='+', label='R-SegLETNet', alpha = 0.4)
print(sum(all_data_my) / len(all_data_my))

print("提升", (sum(all_data_no) / len(all_data_no) - sum(all_data_my) / len(all_data_my)) / (sum(all_data_no) / len(all_data_no)) * 100)


# plt.scatter(range(len(data3)), data3, color='r', marker='+', label='use_my_model')
# plt.scatter(range(len(data3)), data3, color='g', marker='x', label='lab')



plt.xlim(0, len(all_data_other) - 1)
plt.ylim(45,200)
# 添加标题、标签和图例
plt.title('Video Stream RTT')
plt.xlabel('Frame Number')
plt.ylabel('Delay (ms)')
plt.legend()  # 显示图例

# 显示图表
plt.show(block=True)
